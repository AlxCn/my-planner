MY PLANNER — FREE ANDROID HOME-SCREEN SETUP

Files: index.html, manifest.webmanifest, sw.js, icon.svg

IMPORTANT PRIVACY NOTE
GitHub Pages on a free account uses a public repository. These files contain the app code, not your calendar entries. The planner saves entries in localStorage in the browser on your device. Do not add personal event data to the repository.

PUBLISH ON GITHUB (ANDROID)
1. Open github.com in Chrome and sign in.
2. Tap +, choose New repository. Name it my-planner. Choose Public (required for GitHub Pages on the free plan). Create repository.
3. On the repository page, choose Add file > Upload files. Upload the four files in this folder (not this README is optional).
4. Tap Commit changes.
5. Open Settings > Pages. Under Build and deployment, choose Deploy from a branch. Choose main and /(root), then Save.
6. Wait a minute or two. The Pages address appears on Settings > Pages, typically https://YOUR-USERNAME.github.io/my-planner/
7. Open that address in Chrome. Tap ⋮ > Install app or Add to Home screen.

If upload on mobile doesn't show multiple files, use the browser's file picker and select each file, or switch Chrome to Desktop site.
